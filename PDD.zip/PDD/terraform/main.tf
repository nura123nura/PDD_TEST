provider "null" {}

resource "null_resource" "pdd_project" {

  provisioner "local-exec" {
    command = "docker compose up -d"
  }

}