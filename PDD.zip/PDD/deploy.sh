#!/bin/bash

echo "PDD проект іске қосылуда..."
docker compose down
docker compose up -d --build

echo "Дайын!"